@extends('layouts.app')

@section('title', 'Test Panel Assessment')

@section('content')
<div class="container">
    <h1>Test Body Panel Assessment</h1>
    <p>This is a test page to verify the route works.</p>
</div>
@endsection